package com.wincomplm._2_challenge._1_fizzbuzz;

public class NumberWordCorrelation {
    private Integer number;
    private String word;

    public NumberWordCorrelation(Integer number, String word) {
        this.number = number;
        this.word = word;
    }

    public Integer getNumber() {
        return number;
    }

    public String getWord() {
        return word;
    }
}