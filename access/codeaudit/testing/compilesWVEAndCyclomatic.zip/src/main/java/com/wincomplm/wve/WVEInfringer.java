/*
 * 
 * Copyright (c) 2019 Wincom Consulting S.L.
 * All Rights Reserved.
 * This source is subject to the terms of a software license agreement.
 * You shall not disclose such confidential information and shall use it only in accordance with the terms and conditions of the license agreement.
 * 
 */
package com.wincomplm.wve;

import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.util.WTException;

/**
 *
 * @author CristianRomero
 */
public class WVEInfringer {

    WTPrincipal principal;

    public void unsafeWVEAdminMaker() throws WTException {
        principal = SessionHelper.manager.setAdministrator();
    }
}
