package com.wincomplm._4_student_effort;

public class Main {

    public static void main(String[] args) {
        //TODO put your code changes in here
    }
}
