package com.wincomplm._1_study._1_hello_world;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("hello world");
    }
}