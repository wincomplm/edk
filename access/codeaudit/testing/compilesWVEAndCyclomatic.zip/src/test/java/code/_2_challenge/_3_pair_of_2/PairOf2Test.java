package code._2_challenge._3_pair_of_2;


import java.util.Map;

import static java.util.Map.entry;

public class PairOf2Test {
    public static Map<Integer[], Integer> data = Map.ofEntries(
            entry(new Integer[]{3, 2, -3, -2, 3, 0}, 2),
            entry(new Integer[]{1, 1, 0, -1, -1}, 2),
            entry(new Integer[]{5, 9, -5, 7, -5}, 1)
    );

 
}